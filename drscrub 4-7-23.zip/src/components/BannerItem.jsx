import React from "react";

function BannerItem(props) {
  return (
    <>
      <div>
        
      </div>
    </>
  );
}

export default BannerItem;
