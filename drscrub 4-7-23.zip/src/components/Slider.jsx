import React from "react";

function Slider() {
  return (
    <>
    
    </>
  );
}

export default Slider;
