const BassURl = `https://drscrubsadmin.digitalnawab.com/api`;
export default BassURl;

