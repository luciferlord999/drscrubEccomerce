const imageURl = `https://drscrubsadmin.digitalnawab.com/`;
export default imageURl;
