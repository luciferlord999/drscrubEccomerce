import React from "react";

function AddEmboidery() {
  return <div>AddEmboidery</div>;
}

export default AddEmboidery;
