import React from 'react'

function Faq() {
  return (
    <div>Faq</div>
  )
}

export default Faq